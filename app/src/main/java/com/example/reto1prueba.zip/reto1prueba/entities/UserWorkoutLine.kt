package com.example.reto1prueba.entities

data class UserWorkoutLine (
    val userId: Int = 0,
    val workoutId: Int = 0,
    val doneDate: String? = null,
)