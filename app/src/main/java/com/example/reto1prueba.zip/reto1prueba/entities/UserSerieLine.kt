package com.example.reto1prueba.entities

data class UserSerieLine (
    val userId: Int = 0,
    val serieId: Int = 0,
)