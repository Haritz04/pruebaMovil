package com.example.reto1prueba.entities

data class Exercise (
    var id: Int = 0,
    var workoutId: Int = 0,
    var name: String? = null,
    var descript: String? = null
)

