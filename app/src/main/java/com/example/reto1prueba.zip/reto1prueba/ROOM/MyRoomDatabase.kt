package com.example.reto1prueba.ROOM

class MyRoomDatabase {
}