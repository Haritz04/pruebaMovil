package com.example.reto1prueba.entities

data class UserExerciseLine (
    val userId: Int = 0,
    val exerciseId: Int = 0,
)