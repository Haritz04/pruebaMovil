package com.example.reto1prueba.firebase.exception

class DBException : Exception {

    companion object {
        private const val serialVersionUID: Long = 1L
    }

    constructor() : super()

    constructor(message: String) : super(message)

}