package com.example.reto1prueba.ROOM.DAO

class UserDAO {
}